package org.zerock.goods.vo;

import lombok.Data;

@Data
public class GoodsColorVO {
	
	
	private Long goods_color_no;
	private String color_name;
	private Long goods_no;
	
	
	
	
	
	
	
}
