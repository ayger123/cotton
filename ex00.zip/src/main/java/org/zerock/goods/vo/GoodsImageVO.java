package org.zerock.goods.vo;

import lombok.Data;

@Data
public class GoodsImageVO {
	
	
	private Long goods_image_no;
	private String image_name;
	private Long goods_no;
	
	
	
	
	
	
	
}
